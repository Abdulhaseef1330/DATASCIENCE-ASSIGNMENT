from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml import Pipeline

# Step 1: Initialize a Spark session
spark = SparkSession.builder.appName("SpamEmailClassification").getOrCreate()

# Step 2: Load and prepare the sample data
# For simplicity, we create a DataFrame with sample data directly
data = [
    (0.1, 0.5, 1.0, 0.0, 1.0),  # Not spam
    (0.2, 0.4, 0.0, 1.0, 1.0),  # Not spam
    (0.9, 0.8, 0.0, 1.0, 0.0),  # Spam
    (0.7, 0.7, 0.0, 0.0, 0.0),  # Spam
    (0.6, 0.6, 1.0, 0.0, 1.0),  # Not spam
    (0.9, 0.7, 0.0, 1.0, 0.0)   # Spam
]
columns = ["word_freq_free", "word_freq_money", "char_freq_$", "char_freq_!", "label"]

df = spark.createDataFrame(data, columns)

# Step 3: Assemble features into a feature vector
feature_cols = ["word_freq_free", "word_freq_money", "char_freq_$", "char_freq_!"]
assembler = VectorAssembler(inputCols=feature_cols, outputCol="features")

# Step 4: Train the Logistic Regression model
# Initialize LogisticRegression with the feature and label columns
lr = LogisticRegression(featuresCol="features", labelCol="label")

# Create a pipeline with the assembler and logistic regression
pipeline = Pipeline(stages=[assembler, lr])

# Fit the pipeline model
pipeline_model = pipeline.fit(df)

# Step 5: Make predictions and evaluate the model
predictions = pipeline_model.transform(df)

# Select example rows to display
predictions.select("features", "label", "prediction", "probability").show()

# Evaluate the model
evaluator = BinaryClassificationEvaluator(labelCol="label", rawPredictionCol="rawPrediction", metricName="areaUnderROC")
roc_auc = evaluator.evaluate(predictions)
print(f"Area Under ROC Curve (AUC): {roc_auc}")

