from pyspark.sql import SparkSession
from pyspark.sql.functions import col, unix_timestamp
from pyspark.ml.feature import VectorAssembler, StringIndexer
from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.evaluation import RegressionEvaluator


spark = SparkSession.builder.appName("SalesForecast").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

#1. Load and Preprocess Data
data = spark.read.csv("file:/home/hduser/hive/data/txns", header=False, inferSchema=True)\
.toDF("txnid","txndate","amount","custid","category","product","city","state","paymenttype")

# Show the schema and some sample data
data.printSchema()
data.show(5)

data = data.withColumn("sales_date", unix_timestamp(col("sales_date"), "MM-dd-yyyy").cast("timestamp"))

indexers = [
    StringIndexer(inputCol="product", outputCol="product_index"),
    StringIndexer(inputCol="category", outputCol="category_index"),
    StringIndexer(inputCol="city", outputCol="city_index"),
    StringIndexer(inputCol="state", outputCol="state_index")
]

for indexer in indexers:
    data = indexer.fit(data).transform(data)


assembler = VectorAssembler(
    inputCols=["product_index", "category_index", "city_index", "state_index", "sales_date"],
    outputCol="features"
)
data = assembler.transform(data)


final_data = data.select(col("features"), col("sales_amount").alias("label"))

#2. Split Data
train_data, test_data = final_data.randomSplit([0.8, 0.2])

#Train Random Forest Model
rf = RandomForestRegressor(featuresCol="features", labelCol="label", numTrees=100)
rf_model = rf.fit(train_data)

predictions = rf_model.transform(test_data)
predictions.select("prediction", "label", "features").show(5)


evaluator = RegressionEvaluator(labelCol="label", predictionCol="prediction", metricName="rmse")
rmse = evaluator.evaluate(predictions)
print(f"Root Mean Squared Error (RMSE) on test data = {rmse}")


# Assuming you have a new dataframe 'future_data' prepared with the same structure
# Preprocess future_data similarly
future_data = ...  # Your future data preparation steps

# Transform future data using the same VectorAssembler
future_data = assembler.transform(future_data)

# Make predictions
future_predictions = rf_model.transform(future_data)
future_predictions.select("prediction", "features").show(5)


