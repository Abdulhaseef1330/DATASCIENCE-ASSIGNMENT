from pyspark.sql import SparkSession
from pyspark.sql.functions import unix_timestamp, col
from pyspark.ml import Pipeline
from pyspark.ml.feature import VectorAssembler, StringIndexer
from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.evaluation import RegressionEvaluator

# Initialize Spark session
spark = SparkSession.builder.appName("SalesForecast").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# Load the data
data = spark.read.csv("file:/home/hduser/hive/data/txns", header=False, inferSchema=True)\
.toDF("txnid","sales_date","custid","sales_amount","category","product","city","state","paymenttype")

# Show the schema and some sample data
data.printSchema()
data.show(5)

# Convert sales_date to timestamp
data = data.withColumn("sales_date", unix_timestamp("sales_date", "yyyy-MM-dd").cast("double"))

# String indexing for categorical columns
indexers = [
    StringIndexer(inputCol="product", outputCol="product_index"),
    StringIndexer(inputCol="category", outputCol="category_index"),
    StringIndexer(inputCol="city", outputCol="city_index"),
    StringIndexer(inputCol="state", outputCol="state_index")
]

# Assemble features into a single vector
assembler = VectorAssembler(
    inputCols=["product_index", "category_index", "city_index", "state_index", "sales_date"],
    outputCol="features"
)

# Initialize RandomForestRegressor
rf = RandomForestRegressor(featuresCol="features", labelCol="sales_amount", numTrees=100)

# Create the pipeline
pipeline = Pipeline(stages=indexers + [assembler, rf])

# Prepare the data
data_prepared = pipeline.fit(data).transform(data)

# Select the relevant columns
final_data = data_prepared.select("features", col("sales_amount").alias("label"))

# Split the data into training and testing sets
train_data, test_data = final_data.randomSplit([0.8, 0.2])

# Train the model
rf_model = pipeline.fit(train_data)

# Make predictions
predictions = rf_model.transform(test_data)
predictions.select("prediction", "label", "features").show(5)

# Evaluate the model
evaluator = RegressionEvaluator(labelCol="label", predictionCol="prediction", metricName="rmse")
rmse = evaluator.evaluate(predictions)
print(f"Root Mean Squared Error (RMSE) on test data = {rmse}")

# Assuming you have a new dataframe 'future_data' prepared with the same structure
# Load and preprocess future data
future_data = spark.read.csv("file:/home/hduser/SparkML-Workouts/future-sales-data.csv", header=False, inferSchema=True)\
.toDF("txnid","sales_date","custid","category","product","city","state","paymenttype")

future_data = future_data.withColumn("sales_date", unix_timestamp("txndate", "yyyy-MM-dd").cast("double"))

# Transform future data using the trained pipeline
future_predictions = rf_model.transform(future_data)
future_predictions.select("prediction", "features").show(5)

