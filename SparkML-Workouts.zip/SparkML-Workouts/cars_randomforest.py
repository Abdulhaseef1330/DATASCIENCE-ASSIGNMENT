from pyspark.ml.feature import VectorAssembler
from pyspark.sql.functions import isnan, when, count, col, lit
from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml import Pipeline
from pyspark.ml.tuning import CrossValidator
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.tuning import ParamGridBuilder

data= spark.read.csv("data.csv", inferSchema=True, header=True)
data.printSchema()

data.describe()

data = data.na.drop()

assembler = VectorAssembler(inputCols=["Year",
                                      "Engine HP",
                                      "Engine Cylinders",
                                      "Number of Doors",
                                      "highway MPG",
                                      "city mpg",
                                      "Popularity"], outputCol = "Attributes")

regressor = RandomForestRegressor(featuresCol = "Attributes", labelCol="MSRP")
pipeline = Pipeline(stages=[assembler, regressor])

pipeline.write().overwrite().save("car_predicton_pipeline")

paramGrid = ParamGridBuilder().addGrid(regressor.numTrees, [100, 500]).build()
pipelineModel = Pipeline.load("pipeline")

/*
Creating a cross validator for hyperparameter tuning
Hyperparameter tuning is an essential step for creating an optimized machine learning model as it chooses the best parameters needed for the model.

Cross-validation is a resampling procedure that is used to evaluate machine learning models. It ensures an unbiased model.
*/

crossval = CrossValidator(estimator=pipelineModel,
estimatorParamMaps = paramGrid,
evaluator= RegressionEvaluator(labelCol = "MSRP"),
                               numFolds=3)

Training and prediction:
train_data, test_data = data.randomSplit([0.8,0.2], seed=123)
cvModel= crossval.fit(train_data)
pred = cvModel.transform(test_data)
pred.select("MSRP", "prediction").show()

Evaluating model’s performance
eval = RegressionEvaluator(labelCol = "MSRP")
rmse = eval.evaluate(pred)
mse= eval.evaluate(pred, {eval.metricName: "mse"})
mae= eval.evaluate(pred, {eval.metricName: "mae"})
r2 = eval.evaluate(pred, {eval.metricName: "r2"})

print("RMSE: %.3f" %rmse)
print("MSE: %.3f" %mse)
print("MAE: %.3f" %mae)
print("r2: %.3f" %r2)