from pyspark.sql import SparkSession
from pyspark.sql.functions import col, unix_timestamp,year,month,dayofmonth
from pyspark.ml.feature import VectorAssembler, StringIndexer
from pyspark.ml.regression import RandomForestRegressor,DecisionTreeRegressor
from pyspark.ml.evaluation import RegressionEvaluator


spark = SparkSession.builder.appName("SalesForecast").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

data = spark.read.csv("file:/home/hduser/hive/data/txns", header=False, inferSchema=True)\
.toDF("txnid","txndate","amount","custid","category","product","city","state","paymenttype")


data = data.withColumn("sales_date", unix_timestamp(col("txndate"), "MM-dd-yyyy").cast("timestamp"))
data = data.withColumn("year", year(col("sales_date")))
data = data.withColumn("month", month(col("sales_date")))
data = data.withColumn("day", dayofmonth(col("sales_date")))

indexers = [
    StringIndexer(inputCol="product", outputCol="product_index"),
    StringIndexer(inputCol="category", outputCol="category_index"),
    StringIndexer(inputCol="city", outputCol="city_index"),
    StringIndexer(inputCol="state", outputCol="state_index")
]
for indexer in indexers:
    data = indexer.fit(data).transform(data)
assembler = VectorAssembler(
    inputCols=["product_index", "category_index", "city_index", "state_index", "year","month","day"],
    outputCol="features"
)
data = assembler.transform(data)
final_data = data.select(col("features"), col("amount").alias("label"))

#Split Data
train_data, test_data = final_data.randomSplit([0.8, 0.2])

#Train Random Forest Model
rt_rf = RandomForestRegressor(featuresCol="features", labelCol="label", maxBins=320)
rf_model = rt_rf.fit(train_data)

rt_dt = DecisionTreeRegressor(featuresCol="features", labelCol="label", maxBins=320)
dt_model = rt_dt.fit(train_data)

rt_predictions = rf_model.transform(test_data)
rt_predictions.select("prediction", "label", "features")

dt_predictions = dt_model.transform(test_data)
dt_predictions.select("prediction", "label", "features")

evaluator = RegressionEvaluator(labelCol="label", predictionCol="prediction", metricName="rmse")

rmse = evaluator.evaluate(rt_predictions)
print(f"Root Mean Squared Error (RMSE) on test data = {rmse}")

rmse = evaluator.evaluate(dt_predictions)
print(f"Root Mean Squared Error (RMSE) on test data = {rmse}")
