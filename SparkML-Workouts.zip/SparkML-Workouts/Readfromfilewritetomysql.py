"""
spark-submit --jars file:/home/hduser/install/mysql-connector-java.jar  Readfromfilewritetomysql.py

"""
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("WritetoMysql").master("local").getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

df = spark.read.format("csv").option("inferschema",True).load("file:/home/hduser/hive/data/custs").toDF("custid","fname","lname","age","prof")

df.write.format("jdbc").option("url","jdbc:mysql://localhost/custdb").option("user","root")\
.option("password","root").option("dbtable","tblcustomer").option("driver","com.mysql.jdbc.Driver").save()

print("Data written into mysql table");
