from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("ReadFromMysql").master("local").getOrCreate()

spark.sparkContext.setLogLevel("ERROR")
   
df = spark.read.format("jdbc") \
.option("url","jdbc:mysql://localhost/test") \
.option("user","root") \
.option("password","root") \
.option("dbtable","customer") \
.option("driver","com.mysql.jdbc.Driver") \
.load()
   
df.show()



