from pyspark import SparkContext
from pyspark.sql import SQLContext

def main():
    sc = SparkContext(master="local", appName="Lab01")
    sc.setLogLevel("ERROR")
    
    sqlc = SQLContext(sc)
    
    df = sqlc.read.format("csv") \
    .option("InferSchema",True) \
    .load("file:/home/hduser/moviesdata.txt") \
    #.toDF("movieid","moviename","releaseyear","rating","duration")
    
    #df1 = df.filter(df.rating >= 3.5)
    
    df1 = df.filter("_c3 >= 3.5")
    
    
    
    #df1.show()
    #by default 20 records,truncate=true
    df1.show(n=100,truncate=False)
    
    #To get schema information
    df1.printSchema()
    



main()
