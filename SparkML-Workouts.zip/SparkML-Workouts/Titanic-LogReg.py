We will be using the data for Titanic where the columns PassengerId, Survived, Pclass, Name, Sex, Age, SibSp, Parch, Ticket, Fare, Cabin, and Embarked. We have to predict whether the passenger will survive or not using the Logistic Regression machine learning model

# Starting the Spark Session 
from pyspark.sql import SparkSession 
spark = SparkSession.builder.appName('Titanic').getOrCreate() 
  
# Reading the data 
df = spark.read.csv('Titanic.csv',inferSchema=True, header=True) 
  
# Showing the data 
df.show()
df.printSchema()

df.columns

Removing NULL Values Columns
# Selecting the columns which are required  
# to train and test the model. 
rm_columns = df.select(['Survived','Pclass', 
                       'Sex','Age','SibSp', 
                       'Parch','Fare','Embarked']) 
  
# Drops the data having null values 
result = rm_columns.na.drop() 
  
# Again showing the data 
result.show()

Convert String Column to Ordinal Columns 
The next task is to convert the string columns (Sex and Embarked) to integral columns as without doing this, we cannot vectorize the data using VectorAssembler. 

# Importing the required libraries 
from pyspark.ml.feature import VectorAssembler, StringIndexer, OneHotEncoder 
  
# Converting the Sex Column 
sexIdx = StringIndexer(inputCol='Sex', 
                               outputCol='SexIndex') 
sexEncode = OneHotEncoder(inputCol='SexIndex', 
                               outputCol='SexVec') 
  
# Converting the Embarked Column 
embarkIdx = StringIndexer(inputCol='Embarked', 
                               outputCol='EmbarkIndex') 
embarkEncode = OneHotEncoder(inputCol='EmbarkIndex', 
                               outputCol='EmbarkVec') 
  
# Vectorizing the data into a new column "features"  
# which will be our input/features class 
assembler = VectorAssembler(inputCols=['Pclass', 
                                       'SexVec','Age', 
                                       'SibSp','Parch', 
                                       'Fare','EmbarkVec'], 
                                    outputCol='features') 

Pipeline to stack the tasks one by one and import and call the Logistic Regression Model.

# Importing Pipeline and Model 
from pyspark.ml import Pipeline 
from pyspark.ml.classification import LogisticRegression 
  
log_reg = LogisticRegression(featuresCol='features', 
                             labelCol='Survived') 
  
# Creating the pipeline 
pipe = Pipeline(stages=[sexIdx, embarkIdx, 
                            sexEncode, embarkEncode, 
                            assembler, log_reg]) 

After pipelining the tasks, we will split the data into training data and testing data to train and test the model.

# Splitting the data into train and test 
train_data, test_data = my_final_data.randomSplit([0.7, .3]) 
  
# Fitting the model on training data 
fit_model = pipeline.fit(train_data) 
  
# Storing the results on test data 
results = fit_model.transform(test_data) 
  
# Showing the results 
results.show() 

Model evaluation using ROC-AUC:

# Importing the evaluator 
from pyspark.ml.evaluation import BinaryClassificationEvaluator 
  
# Calling the evaluator 
res = BinaryClassificationEvaluator 
        (rawPredictionCol='prediction',labelCol='Survived') 
  
# Evaluating the AUC on results 
ROC_AUC = res.evaluate(results) 

print(ROC_AUC)
In general, an AUC value above 0.7 is considered good
