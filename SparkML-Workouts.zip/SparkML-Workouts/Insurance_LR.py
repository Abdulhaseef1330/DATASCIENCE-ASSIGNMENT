"""
Features are as follows:

Age: Age of the customer.
BMI: Body Mass Index of the individual.
Childeren: Number of childeren he/she have.
Smoker: Is that individual a frequent Smoker or not.
Region: Which region/part he/she lives in and,

Charges column is our target/independent feature.
"""

data = spark.read.csv("file:/home/hduser/insurance.csv", inferSchema = True, header = True)
data.show()
data.describe().show()
age = data.corr("age", "charges")
BMI = data.corr("bmi", "charges")

print("Correlation between Age of the person and charges is : {}".format(age))
print("Correlation between BMI of the person and charges is : {}".format(BMI))

from pyspark.ml.feature import StringIndexer

category = StringIndexer(inputCol = "sex", outputCol = "gender_categorical")
categorised = category.fit(data).transform(data)
categorised.show()


category = StringIndexer(inputCol = "smoker", outputCol = "smoker_categorical")
categorised = category.fit(categorised).transform(categorised)
categorised.show()

category = StringIndexer(inputCol = "region", outputCol = "region_categorical")
categorised = category.fit(categorised).transform(categorised)
categorised.show()

from pyspark.ml.linalg import Vector
from pyspark.ml.feature import VectorAssembler

#categorised.columns

concatenating  = VectorAssembler(inputCols=["age","bmi", "children", "gender_categorical", "smoker_categorical", "region_categorical"],outputCol="features")
results = concatenating.transform(categorised)

for_model = results.select("features", "charges")
for_model.show(truncate=False)

#Train Test Split:

train_data, test_data = for_model.randomSplit([0.7,0.3])
train_data.describe().show()


#Model Building
from pyspark.ml.regression import LinearRegression

lr_model = LinearRegression(featuresCol= "features",labelCol="charges")
training_model = lr_model.fit(train_data)

#Model Evaluation
output = training_model.evaluate(train_data)
print(output.r2)
print(output.meanSquaredError)
print(output.meanAbsoluteError)


