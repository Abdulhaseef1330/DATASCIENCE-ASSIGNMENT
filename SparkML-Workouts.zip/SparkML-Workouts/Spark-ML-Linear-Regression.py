"""
To predict insurance data using linear regression in Spark MLlib without using Pipelines, you can follow these steps:

Load the data from a CSV file.
Prepare the data by assembling the features into a feature vector.
Train the Linear Regression model.
Save the trained model.
Load the saved model and make predictions.

"""

from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.regression import LinearRegression
from pyspark.ml.evaluation import RegressionEvaluator


# Step 1: Load the data from a CSV file
file_path = "file:/home/hduser/insurance.csv"  # Path to the CSV file
data = spark.read.csv(file_path, header=True, inferSchema=True)
data.show(5)

# Step 2: Prepare the data
# Assemble features into a feature vector
feature_cols = ["age", "bmi", "children"]  # Modify according to your CSV's columns
assembler = VectorAssembler(inputCols=feature_cols, outputCol="features")
data = assembler.transform(data)

# Select only the necessary columns
data = data.select("features", "charges")

# Step 3: Train the Linear Regression model
# Initialize LinearRegression with the feature and label columns
lr = LinearRegression(featuresCol="features", labelCol="charges")

# Fit the model
lr_model = lr.fit(data)

# Print the coefficients and intercept
print(f"Coefficients: {lr_model.coefficients}")
print(f"Intercept: {lr_model.intercept}")

# Step 4: Save the trained model
model_path = "insurance_linear_regression_model"
lr_model.save(model_path)

# Step 5: Load the saved model and make predictions
from pyspark.ml.regression import LinearRegressionModel

# Load the model
loaded_model = LinearRegressionModel.load(model_path)

# Make predictions
predictions = loaded_model.transform(data)

# Select example rows to display
predictions.select("features", "charges", "prediction").show()

# Evaluate the model
evaluator = RegressionEvaluator(labelCol="charges", predictionCol="prediction", metricName="rmse")
rmse = evaluator.evaluate(predictions)
print(f"Root Mean Squared Error (RMSE): {rmse}")

#=====================================================


# Import necessary libraries
from pyspark.sql import SparkSession
from pyspark.ml import Pipeline
from pyspark.ml.feature import VectorAssembler, StringIndexer, StandardScaler
from pyspark.ml.regression import LinearRegression
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder



# Load the data
data = spark.read.csv("file:/home/hduser/insurance.csv", header=True, inferSchema=True)

# Display the schema of the DataFrame
data.printSchema()

# Data Preprocessing
# Index categorical columns
sex_indexer = StringIndexer(inputCol="sex", outputCol="sexIndexed")
smoker_indexer = StringIndexer(inputCol="smoker", outputCol="smokerIndexed")
region_indexer = StringIndexer(inputCol="region", outputCol="regionIndexed")

# Assemble features into a single vector
assembler = VectorAssembler(
    inputCols=["age", "sexIndexed", "bmi", "children", "smokerIndexed", "regionIndexed"],
    outputCol="features"
)

# Standardize the features
scaler = StandardScaler(inputCol="features", outputCol="scaledFeatures")

# Define the Linear Regression model
lr = LinearRegression(featuresCol="scaledFeatures", labelCol="charges")

# Create the Pipeline
pipeline = Pipeline(stages=[sex_indexer, smoker_indexer, region_indexer, assembler, scaler, lr])

# Split the data into training and test sets
train_data, test_data = data.randomSplit([0.8, 0.2], seed=12345)

# Train the Pipeline
model = pipeline.fit(train_data)

# Make predictions on the test data
predictions = model.transform(test_data)

# Evaluate the model
evaluator = RegressionEvaluator(labelCol="charges", predictionCol="prediction", metricName="rmse")
rmse = evaluator.evaluate(predictions)
print(f"Root Mean Squared Error (RMSE) on test data: {rmse}")

"""
Hyperparameter tuning is a crucial step in the machine learning workflow
to improve the performance of the model by finding the optimal combination of parameters.
"""

# Hyperparameter tuning using CrossValidator
paramGrid = ParamGridBuilder() \
    .addGrid(lr.regParam, [0.01, 0.1, 1.0]) \
    .addGrid(lr.elasticNetParam, [0.0, 0.5, 1.0]) \
    .build()

crossval = CrossValidator(estimator=pipeline,
                          estimatorParamMaps=paramGrid,
                          evaluator=evaluator,
                          numFolds=5)

# Train with CrossValidator
cvModel = crossval.fit(train_data)

# Make predictions with the best model
cvPredictions = cvModel.transform(test_data)

# Evaluate the best model
cvRmse = evaluator.evaluate(cvPredictions)
print(f"Cross-validated Root Mean Squared Error (RMSE) on test data: {cvRmse}")

===============Predict new dataset====================
age,bmi,children
28,26.2,1
35,30.5,2
50,25.5,3


# Step 2: Load the saved pipeline model
model_path = "insurance_pipeline_model"  # Path where the model was saved
loaded_pipeline_model = PipelineModel.load(model_path)

# Step 3: Load the new data
# Assuming the new data is in a CSV file
new_data_path = "new_insurance_data.csv"  # Path to the new CSV file
new_data = spark.read.csv(new_data_path, header=True, inferSchema=True)

# Step 4: Make predictions on the new data
predictions = loaded_pipeline_model.transform(new_data)

# Select example rows to display
predictions.select("features", "prediction").show()


