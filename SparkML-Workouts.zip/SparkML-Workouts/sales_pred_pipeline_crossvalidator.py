from pyspark.sql import SparkSession
from pyspark.sql.functions import year, month, dayofmonth, dayofweek
from pyspark.sql.functions import unix_timestamp, col
from pyspark.ml import Pipeline
from pyspark.ml.feature import StringIndexer, OneHotEncoder, VectorAssembler
from pyspark.ml.regression import LinearRegression
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder


# Initialize Spark session
spark = SparkSession.builder.appName("SalesForecast").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# Load the data
data = spark.read.csv("file:/home/hduser/hive/data/txns", header=False, inferSchema=True)\
.toDF("txnid","txndate","custid","sales_amount","category","product","city","state","paymenttype")

# Show the schema and some sample data
data.printSchema()
data.show(5)

# Convert sales_date to timestamp
df = data.withColumn("sales_date", unix_timestamp(col("txndate"), "MM-dd-yyyy").cast("timestamp"))

# Extract components from sales_date
df = df.withColumn("year", year(df["sales_date"]))
df = df.withColumn("month", month(df["sales_date"]))
df = df.withColumn("dayofmonth", dayofmonth(df["sales_date"]))
df = df.withColumn("dayofweek", dayofweek(df["sales_date"]))

# Index categorical columns
indexers = [
    StringIndexer(inputCol="city", outputCol="cityIndex"),
    StringIndexer(inputCol="state", outputCol="stateIndex"),
    StringIndexer(inputCol="product", outputCol="productIndex"),
    StringIndexer(inputCol="category", outputCol="categoryIndex")
]

# One-hot encode the indexed columns
encoders = [
    OneHotEncoder(inputCol="cityIndex", outputCol="cityVec"),
    OneHotEncoder(inputCol="stateIndex", outputCol="stateVec"),
    OneHotEncoder(inputCol="productIndex", outputCol="productVec"),
    OneHotEncoder(inputCol="categoryIndex", outputCol="categoryVec"),
    OneHotEncoder(inputCol="year", outputCol="yearVec"),
    OneHotEncoder(inputCol="month", outputCol="monthVec"),
    OneHotEncoder(inputCol="dayofmonth", outputCol="dayofmonthVec"),
    OneHotEncoder(inputCol="dayofweek", outputCol="dayofweekVec")
]

# Assemble features
assembler = VectorAssembler(
    inputCols=[
        "cityVec", "stateVec", "productVec", "categoryVec",
        "yearVec", "monthVec", "dayofmonthVec", "dayofweekVec"
    ],
    outputCol="features"
)

# Define the model
lr = LinearRegression(labelCol="sales_amount", featuresCol="features")

# Create a pipeline
pipeline = Pipeline(stages=indexers + encoders + [assembler, lr])

# Split the data into training and test sets
train_data, test_data = df.randomSplit([0.8, 0.2], seed=12345)

# Train the model
model = pipeline.fit(train_data)

# Make predictions
predictions = model.transform(test_data)

# Evaluate the model
evaluator = RegressionEvaluator(
    labelCol="sales_amount",
    predictionCol="prediction",
    metricName="rmse"
)
rmse = evaluator.evaluate(predictions)
print(f"Root Mean Squared Error (RMSE) on test data: {rmse}")

# Cross-validation
paramGrid = ParamGridBuilder() \
    .addGrid(lr.regParam, [0.1, 0.01]) \
    .addGrid(lr.elasticNetParam, [0.0, 0.5, 1.0]) \
    .build()

crossval = CrossValidator(
    estimator=pipeline,
    estimatorParamMaps=paramGrid,
    evaluator=evaluator,
    numFolds=5
)

# Run cross-validation and choose the best set of parameters
cvModel = crossval.fit(train_data)

# Make predictions with the best model
cv_predictions = cvModel.transform(test_data)

# Evaluate the cross-validated model
cv_rmse = evaluator.evaluate(cv_predictions)
print(f"Cross-Validated Root Mean Squared Error (RMSE) on test data: {cv_rmse}")

# Save the model
model.save("file:/home/hduser/SparkML-Workouts/sales_model")
# Load the model
from pyspark.ml.pipeline import PipelineModel
from pyspark.ml.tuning import CrossValidatorModel

loaded_model = PipelineModel.load("file:/home/hduser/SparkML-Workouts/sales_model")

# Predict using the loaded model
loaded_predictions = loaded_model.transform(test_data)
loaded_predictions.show()

