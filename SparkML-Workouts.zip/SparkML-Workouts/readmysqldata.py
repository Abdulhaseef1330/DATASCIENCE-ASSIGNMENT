"""
spark-submit --jars file:/home/hduser/install/mysql-connector-java.jar  readmysqldata.py

"""
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("WritetoMysql").master("local").getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

df = spark.read.format("jdbc").option("url","jdbc:mysql://localhost/custdb").option("user","root")\
.option("password","root").option("dbtable","tblcustomer").option("driver","com.mysql.jdbc.Driver").load()

df1 = df.select("custid","age","prof")

df1.coalesce(1).write.format("json").save("file:/home/hduser/customerjsondata")

print("Data written as json file");
